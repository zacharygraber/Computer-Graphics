using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class RobotArm : MonoBehaviour
{
    public Transform Arm, ForeArm, DigitUpperBase, DigitUpperEnd, DigitLowerBase, DigitLowerEnd, Shoulder, Elbow, WristUpper, WristLower, KnuckleUpper, KnuckleLower;
    private int counter;
    private int period = 360; // in frames
    // Start is called before the first frame update
    void Start()
    {
        Arm.localScale = new Vector3(2,1,1);
        ForeArm.localScale = new Vector3(2,1,1);
        DigitUpperBase.localScale = new Vector3(1, 0.5f, 1);
        DigitUpperEnd.localScale = new Vector3(1, 0.5f, 1);
        DigitLowerBase.localScale = new Vector3(1, 0.5f, 1);
        DigitLowerEnd.localScale = new Vector3(1, 0.5f, 1);

        Arm.localPosition = new Vector2(1, -0.5f);
        ForeArm.localPosition = new Vector2(1, -0.5f);
        DigitUpperBase.localPosition = new Vector2(0.5f, -0.25f);

        DigitUpperEnd.localPosition = new Vector2(0.5f, 0.25f);
        DigitLowerBase.localPosition = new Vector2(0.5f, 0.25f);
        DigitLowerEnd.localPosition = new Vector2(0.5f, -0.25f);
        Shoulder.localPosition = new Vector2(0,0);
        Elbow.localPosition = new Vector2(2,0);
        WristUpper.localPosition = new Vector2(2,0);
        WristLower.localPosition = new Vector2(2,-1);
        KnuckleUpper.localPosition = new Vector2(1, -0.5f);
        KnuckleLower.localPosition = new Vector2(1, 0.5f);

        Shoulder.localEulerAngles = -20 * Vector3.forward;
        Elbow.localEulerAngles =  40 * Vector3.forward;
        WristUpper.localEulerAngles = 45 * Vector3.forward;
        KnuckleUpper.localEulerAngles = -75 * Vector3.forward;
        WristLower.localEulerAngles = -45 * Vector3.forward;
        KnuckleLower.localEulerAngles = 70 * Vector3.forward;

        counter = (period / 2);
    }

    // Update is called once per frame
    void Update()
    {
        // Provided Animation
        // Elbow.localEulerAngles += Vector3.forward * Time.deltaTime * 60;
        // Shoulder.localEulerAngles -= Vector3.forward * Time.deltaTime * 80;

        // Fingers Opening and Closing
        if (counter == period - 1) {
            counter = -1 * period;
        }
        WristUpper.localEulerAngles = WristUpper.localEulerAngles + ((counter >= 0 ? 1 : -1) * (Vector3.forward * Time.deltaTime * 20));
        WristLower.localEulerAngles = WristLower.localEulerAngles + ((counter >= 0 ? -1 : 1) * (Vector3.forward * Time.deltaTime * 20));
        counter++;
    }
}
