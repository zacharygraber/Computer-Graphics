using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour
{
    private GameObject playerObj;
    // Start is called before the first frame update
    void Start()
    {
        playerObj = GameObject.Find("Player");
    }

    // Update is called once per frame
    void Update()
    {
        // Get the player's position every frame and mimic the x,z location in the camera
        Vector3 playerPos = playerObj.transform.position;
        transform.position = new Vector3(playerPos.x, transform.position.y, playerPos.z);
    }
}
